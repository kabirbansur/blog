export const environment = {
  production: true,
  base_url:'https://gorest.co.in/public/v2/'
};
